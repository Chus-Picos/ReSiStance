#!/usr/bin/env python
# -*- coding: utf-8 -*-

import gtk

class ResistanceWindowContent(gtk.VBox):  

    def update_content(self):
        pass
